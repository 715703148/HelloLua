
-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end

local function main()
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    local cclog = function(...)
        print(string.format(...))
    end

    require "hello2"
    cclog("result is " .. myadd(3, 5))

    ---------------

    -- create MyLayer
    local function createMyLayer()
    	local myLayer = CCLayer:create()
    	
        local sprite = CCSprite:create("dog.png")
        sprite:setPosition(240,160)
        myLayer:addChild(sprite)

    	return myLayer
    end

    -- run
    local sceneGame = CCScene:create()
    sceneGame:addChild(createMyLayer())
    CCDirector:sharedDirector():replaceScene(sceneGame)
end

xpcall(main, __G__TRACKBACK__)
